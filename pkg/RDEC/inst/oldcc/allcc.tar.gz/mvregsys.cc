/* mvregsys.c -- system for multivariate regression analysis */
/* based on gaussian likelihood */

/* basic tasks: 1) evaluate gaussian likelihood for a collection */
/* of structured covariance matrices depending on a small number of */
/* parameters; 2) obtain GLS estimates of regression with block-diagonal */
/* weight matrices (based on structured covariance matrices); 3) interface */
/* these activities to Splus */

#include "MC++.h"
#include "mat_and_scalar.h"
#include <math.h>

#define NCLUST 50000

double Log(double x){ return log(x); }

jmp_buf mcpp_env;

double mvnlik( matrix x, matrix y, matrix id, matrix beta, double sig2, double rho );
double rdec_mvnlik( matrix x, matrix y, matrix id, matrix meta, matrix beta, matrix omega,
			   double sig2 );
matrix cs( double rho, int n );

/*
main()
{
matrix x = matread("X");
matrix y = matread("Y");
matrix id = matread("ID");
matrix beta = matread("BETA");
double sig2 = 1.78231*1.78231;
d int* n, int* p)
{
ouble rho =  0.225675; 
cout << beta;
double hack = mvnlik( x, y, id, beta, sig2, rho );
cout << hack;
}
*/

mat_and_scalar glsbeta_sig2( matrix, matrix, matrix, double );
matrix cs( double rho, int n );

extern "C" glsbeta_sig2_intf( double* x, int*n, int* p, double* y, double* id, double* rho, double* beta , double* sig2)
{
matrix X = from_S(x, *n, *p);
matrix Y = from_S(y, *n, 1);
matrix ID = from_S(id, *n, 1);
double RHO = *rho;
mat_and_scalar BETA_SIG2 = glsbeta_sig2( X, Y, ID, RHO );
to_S( BETA_SIG2.mat , beta );
*sig2 = BETA_SIG2.scalar;
return(0);
}

extern "C" eval_quadform_bdmat_cs_intf( double* x, int* n, int* p, double* id, double* rho , double* qfp)
{
matrix X[NCLUST];
matrix Xin = from_S(x, *n, *p);
matrix IDin = from_S(id, *n, 1);
int M = split(Xin, IDin, X);

matrix qf = newmat( Xin.cols(), Xin.cols() );
 
int i;
for (i = 0 ; i < M ; i++ )
        {
        int ni = X[i].rows();
        matrix Vinv = sweep( cs( *rho, ni ) );
        qf = qf + (transp(X[i]) * Vinv * X[i] );
        }
to_S(qf, qfp);
return(0);
}

extern "C" eval_wtd_inrprod_cs_intf( double* x, int* n, int* p, double*y, int* q, double* id, double* rho , double* wipp)
{
matrix X[NCLUST];
matrix Y[NCLUST];
matrix Xin = from_S(x, *n, *p);
matrix Yin = from_S(y, *n, *q);
matrix IDin = from_S(id, *n, 1);
int M = split(Xin, IDin, X);
int M2 = split(Yin, IDin, Y);

matrix wip = newmat( Xin.cols(), Yin.cols() );
 
int i;
for (i = 0 ; i < M ; i++ )
        {
        int ni = X[i].rows();
        matrix Vinv = sweep( cs( *rho, ni ) );
        wip = wip + (transp(X[i]) * Vinv * Y[i] );
        }
to_S(wip, wipp);
return(0);
}

mat_and_scalar glsbeta_sig2( matrix x, matrix y, matrix id, double rho)
{
/* not a fully general implementation -- assumes the */
/* multivariate structure is given by the parameter rho */
/* should pass the function that evaluates the covariance */
/* matrix, and a vector of parameters */

matrix X[NCLUST];
matrix Y[NCLUST];
int M = split(x, id, X);
int M2 = split(y, id, Y);
int n = y.rows();
int i;

matrix part1 = newmat( x.cols(), x.cols() );
matrix part2 = newmat( x.cols(), 1 );

for (i = 0 ; i < M ; i++ )
	{
	int ni = X[i].rows();
	matrix Vinv = sweep( cs( rho, ni ) );
	matrix tmp = transp(X[i]) * Vinv;
	matrix ytmp = transp(Y[i]) * Vinv;
	part1 = part1 + tmp * X[i] ;
	part2 = part2 + tmp * Y[i] ;
	}
matrix beta= sweep(part1)*part2;

matrix s2num = newmat(1,1);
for (i = 0 ; i < M ; i++ )
	{
	int ni = X[i].rows();
	matrix Vinv = sweep( cs( rho, ni ) );
	matrix ei = Y[i] - X[i]*beta;
	s2num = s2num + transp(ei)*Vinv*ei;
	}
double sig2 = *s2num.mathead() / (double)n;
mat_and_scalar bs = mat_and_scalar( beta, sig2 );
return bs;
}


extern "C" mvgl_intf( double* x, int* n, int*p, double*  y,double*  id,double*  beta,
		   double* sig2, double*  rho , double* m2ll)
{
/* not fully general, assumes the multivariate structure depends */
/* only on the parameter rho */

matrix X = from_S(x, *n, *p);
matrix Y = from_S(y, *n, 1);
matrix ID = from_S(id, *n, 1);
matrix BETA = from_S(beta, *p, 1);
double RHO = *rho;
double SIG2 = *sig2;
*m2ll = mvnlik( X, Y, ID, BETA, SIG2, RHO );
return(0);
}

extern "C" rdec_mvgl_intf( double* x, int* n, int*p, double*  y,double*  id,double* meta,double*  beta,
		   double* sig2, double*  omega , double* m2ll)
{
matrix X = from_S(x, *n, *p);
matrix Y = from_S(y, *n, 1);
matrix ID = from_S(id, *n, 1);
matrix META = from_S( meta, *n, 1);
matrix BETA = from_S(beta, *p, 1);
matrix OMEGA = from_S(omega, 2, 1);
double SIG2 = *sig2;
*m2ll = rdec_mvnlik( X, Y, ID, META, BETA, OMEGA, SIG2 );
return(0);
}

matrix dec( matrix& omega, matrix& meta )
{
/* evaluate a damped exponential correlation matrix of order */
/* n with parameters omega=c(gamma,theta) and line coordinates in meta */

int n = meta.rows();
matrix V = newmat(n,n);
int i, j;
double* cur = V.mathead();
double gamma = omega.el(0,0);
double theta = omega.el(1,0);
for ( i = 0 ; i < n ; i++ )
	{
	for ( j = 0 ; j < n ; j++ )
		{
		if (i == j) *cur  = 1.0;
		else
			{
			double s = fabs(put_el(meta,j,0)-put_el(meta,i,0));
			if ( theta < 0.001 )
				*cur = gamma;
			else if ( theta > .999 && theta < 1.001 )
				*cur = pow(gamma,s);
			else *cur = pow(gamma,pow(s,theta));
			}
		cur++;
		}
	}
return V;
}

matrix d_dec_d_gamma( matrix& omega, matrix& meta )
{
/* derivative wrt gamma of a damped exponential correlation matrix of order */
/* n with parameters omega=c(gamma,theta) and line coordinates in meta */

int n = meta.rows();
matrix V = newmat(n,n);
int i, j;
double* cur = V.mathead();
double gamma = omega.el(0,0);
double theta = omega.el(1,0);
double stt = 0.;
for ( i = 0 ; i < n ; i++ )
	{
	for ( j = 0 ; j < n ; j++ )
		{
		if (i == j) *cur  = 0.0;
		else
			{
			double s = fabs(put_el(meta,j,0)-put_el(meta,i,0));
			if (theta < .001) stt = 1.;
			else if (theta > .999 && theta < 1.001) stt=s;
			else stt = pow(s,theta);
			*cur = pow(gamma,stt)*stt/gamma;
			}
		cur++;
		}
	}
return V;
}

matrix d2_dec_d_gamma2( matrix& omega, matrix& meta )
{
/* derivative wrt gamma of a damped exponential correlation matrix of order */
/* n with parameters omega=c(gamma,theta) and line coordinates in meta */

int n = meta.rows();
matrix V = newmat(n,n);
int i, j;
double* cur = V.mathead();
double gamma = omega.el(0,0);
double theta = omega.el(1,0);
double stt = 0.;
for ( i = 0 ; i < n ; i++ )
	{
	for ( j = 0 ; j < n ; j++ )
		{
		if (i == j) *cur  = 0.0;
		else
			{
			double s = fabs(put_el(meta,j,0)-put_el(meta,i,0));
			if (theta < .001) stt = 1.;
			else if (theta > .999 && theta < 1.001) stt=s;
			else stt = pow(s,theta);
			*cur = pow(gamma,stt-2.)*(pow(s,2.*theta)-stt);
			}
		cur++;
		}
	}
return V;
}

matrix d2_dec_d_theta2( matrix& omega, matrix& meta )
{
/* derivative wrt gamma of a damped exponential correlation matrix of order */
/* n with parameters omega=c(gamma,theta) and line coordinates in meta */

int n = meta.rows();
matrix V = newmat(n,n);
int i, j;
double* cur = V.mathead();
double gamma = omega.el(0,0);
double theta = omega.el(1,0);
double stt = 0.;
for ( i = 0 ; i < n ; i++ )
	{
	for ( j = 0 ; j < n ; j++ )
		{
		if (i == j) *cur  = 0.0;
		else
			{
			double s = fabs(put_el(meta,j,0)-put_el(meta,i,0));
			if (theta < .001) stt = 1.;
			else if (theta > .999 && theta < 1.001) stt=s;
			else stt = pow(s,theta);
			*cur = Log(s)*Log(s)*pow(gamma,stt)*Log(gamma)*(pow(s,2.*theta)*Log(gamma)+stt);
			}
		cur++;
		}
	}
return V;
}

matrix d2_dec_d_gamma_d_theta( matrix& omega, matrix& meta )
{
/* derivative wrt gamma of a damped exponential correlation matrix of order */
/* n with parameters omega=c(gamma,theta) and line coordinates in meta */

int n = meta.rows();
matrix V = newmat(n,n);
int i, j;
double* cur = V.mathead();
double gamma = omega.el(0,0);
double theta = omega.el(1,0);
double stt = 0.;
for ( i = 0 ; i < n ; i++ )
	{
	for ( j = 0 ; j < n ; j++ )
		{
		if (i == j) *cur  = 0.0;
		else
			{
			double s = fabs(put_el(meta,j,0)-put_el(meta,i,0));
			if (theta < .001) stt = 1.;
			else if (theta > .999 && theta < 1.001) stt=s;
			else stt = pow(s,theta);
			*cur = Log(s)*pow(gamma,stt-1.)*(pow(s,2.*theta)*Log(gamma)+stt);
			}
		cur++;
		}
	}
return V;
}

matrix d_dec_d_theta( matrix& omega, matrix& meta )
{
/* derivative wrt gamma of a damped exponential correlation matrix of order */
/* n with parameters omega=c(gamma,theta) and line coordinates in meta */

int n = meta.rows();
matrix V = newmat(n,n);
int i, j;
double* cur = V.mathead();
double gamma = omega.el(0,0);
double theta = omega.el(1,0);
double stt = 0.;
for ( i = 0 ; i < n ; i++ )
	{
	for ( j = 0 ; j < n ; j++ )
		{
		if (i == j) *cur  = 0.0;
		else
			{
			double s = fabs(put_el(meta,j,0)-put_el(meta,i,0));
			if (theta < .001) stt = 1.;
			else if (theta > .999 && theta < 1.001) stt=s;
			else stt = pow(s,theta);
			*cur = pow(gamma,stt)*stt*Log(s)*Log(gamma);
			}
		cur++;
		}
	}
return V;
}

extern "C" eval_quadform_bdmat_dec_intf( double* x, int* n, int* p, double* id, double* meta,
					   double* omega, double* qfp)
{
matrix X[NCLUST];
matrix META[NCLUST];
matrix Xin = from_S(x, *n, *p);
matrix IDin = from_S(id, *n, 1);
matrix OMEGAin = from_S(omega, 2, 1);
matrix METAin = from_S(meta, *n, 1);
int M = split(Xin, IDin, X);
int M2 = split(METAin, IDin, META);

matrix qf = newmat( Xin.cols(), Xin.cols() );
 
int i;
for (i = 0 ; i < M ; i++ )
        {
        int ni = X[i].rows();
        matrix Vinv = sweep( dec( OMEGAin, META[i] ));
        qf = qf + (transp(X[i]) * Vinv * X[i] );
        }
to_S(qf, qfp);
return(0);
}

extern "C" eval_det_bdmat_dec_intf( int* n, double* id, double* meta,
					   double* omega, double* detout)
{
matrix META[NCLUST];
matrix IDin = from_S(id, *n, 1);
matrix OMEGAin = from_S(omega, 2, 1);
matrix METAin = from_S(meta, *n, 1);
int M = split(METAin, IDin, META);

double odet = 0.;

int i;
for (i = 0 ; i < M ; i++ )
        {
	matrix tdec = dec( OMEGAin, META[i] );
	matrix tdet = symdet(tdec);
	double thedet = tdet.el(0,0);
        odet = odet + Log( tdet.el(0,0) );
        }
*detout = odet;
return(0);
}


extern "C" eval_det_bdmat_cs_intf( int* n, double* id, double* rho, double* detout)
{
matrix ID[NCLUST];
matrix IDin = from_S(id, *n, 1);
int M = split(IDin, IDin, ID);

double odet = 0.;

int i;
for (i = 0 ; i < M ; i++ )
        {
	int ni = ID[i].rows();
	matrix tdec = cs( *rho, ni );
	matrix tdet = symdet(tdec);
	double thedet = tdet.el(0,0);
        odet = odet + Log( tdet.el(0,0) );
        }
*detout = odet;
return(0);
}


extern "C" eval_wtd_inrprod_dec_intf( double* x, int* n, int* p, double*y, int* q, double* id, double* omega ,
					double* meta, double* wipp)
{
matrix X[NCLUST];
matrix Y[NCLUST];
matrix META[NCLUST];
matrix Xin = from_S(x, *n, *p);
matrix Yin = from_S(y, *n, *q);
matrix IDin = from_S(id, *n, 1);
matrix OMEGAin = from_S(omega, 2, 1);
matrix METAin = from_S(meta, *n, 1);
int M = split(Xin, IDin, X);
int M2 = split(Yin, IDin, Y);
int M3 = split(METAin, IDin, META);

matrix wip = newmat( Xin.cols(), Yin.cols() );
 
int i;
for (i = 0 ; i < M ; i++ )
        {
        int ni = X[i].rows();
        matrix Vinv = sweep( dec( OMEGAin, META[i] ) );
        wip = wip + (transp(X[i]) * Vinv * Y[i] );
        }
to_S(wip, wipp);
return(0);
}

matrix cs( double rho, int n )
{
/* evaluate a compound symmetry correlation matrix of order */
/* n with off-diagonal element rho */

matrix V = newmat(n,n);
int i, j;
double* cur = V.mathead();
for ( i = 0 ; i < n ; i++ )
	{
	for ( j = 0 ; j < n ; j++ )
		{
		if (i == j) *cur  = 1.0;
		else *cur = rho;
		cur++;
		}
	}
return V;
}

matrix d_cs_d_rho( int n )
{
/* take derivative of cs corr matrix with respect to rho */
matrix V = col_1s(n) * transp(col_1s(n));
matrix I = ident(n);
return V-I;
}

/* score function callable from S */
/* note that this is derivative of log likelihood */
/* if -2lnL is used as objective function, should rescale */
extern "C" score_mvg_cs_intf( double* rho, double* beta, double* sig2, 
				 double* x, double* y, double* id, int* n, int* p, double* scbeta,
				 double* scsig2, double* scrho)
{
matrix X[NCLUST];
matrix Y[NCLUST];
matrix Xin = from_S(x, *n, *p);
matrix Yin = from_S(y, *n, 1);
matrix ID = from_S(id, *n, 1);
matrix BETA = from_S( beta, *p, 1);
double RHO = *rho;
double SIG2 = *sig2;

int m = split( Xin, ID, X );
m = split( Yin, ID, Y );

double sc_rho = 0.;
double sc_sig2 = 0.;
matrix sc_beta = BETA-BETA; 

for ( int i = 0 ; i < m ; i++ )
	{
	int ni = X[i].rows();
	matrix ei = Y[i] - X[i] * BETA;
	matrix S = SIG2 * cs( RHO, ni );
	matrix iS = sweep(S);
	sc_rho += trace( iS*(ei*transp(ei)-S)*iS*SIG2*d_cs_d_rho( ni ) );
	sc_sig2 += trace( iS*(ei*transp(ei)-S)*iS*cs( RHO, ni ) );
	sc_beta = sc_beta + transp(X[i])*iS*ei;
	}
to_S(sc_beta, scbeta);
*scsig2 = .5*sc_sig2;
*scrho = .5*sc_rho;  
return(0);
}

extern "C" score_mvg_dec_intf( double* omega, double* beta, double* sig2, double* x,
				 double* y, double* id, double* s, int* n,
				 int* p, double* scomega )
/* log L is objective function; rescale for -2 log L if needed */
{
matrix X[NCLUST];
matrix Y[NCLUST];
matrix META[NCLUST];

matrix Xin = from_S(x, *n, *p);
matrix Yin = from_S(y, *n, 1);
matrix ID = from_S(id, *n, 1);
matrix METAin = from_S(s, *n, 1);
matrix BETA = from_S( beta, *p, 1);
double SIG2 = *sig2;
matrix OMEGA = from_S( omega, 2, 1 );

int M = split(Xin, ID, X);
int M2 = split(Yin, ID, Y);
int M3 = split(METAin, ID, META);

double sc_gamma = 0.;
double sc_theta = 0.;

for ( int i = 0 ; i < M ; i++ )
	{
        int ni = X[i].rows();
	matrix ei = Y[i] - X[i] * BETA;
	matrix S = SIG2 * dec( OMEGA, META[i] );
	matrix iS = sweep(S);
	matrix tmp = iS*(ei*transp(ei)-S)*iS;
	sc_gamma += trace( tmp*SIG2*d_dec_d_gamma( OMEGA, META[i] ));
	sc_theta += trace( tmp*SIG2*d_dec_d_theta( OMEGA, META[i] ));
	}
*scomega = .5*sc_gamma;  
*(scomega+1) = .5*sc_theta;
return(0);
}




/* hessian function callable from S */
extern "C" hess_mvg_cs_intf( double* rho, double* beta, double* sig2, 
				 double* x, double* y, double* id, int* n, int* p, double* hbetabeta,
				 double* hbetarho, double* hsig2sig2, double* hrhosig2, double* hrhorho)
{
matrix X[NCLUST];
matrix Y[NCLUST];
matrix Xin = from_S(x, *n, *p);
matrix Yin = from_S(y, *n, 1);
matrix ID = from_S(id, *n, 1);
matrix BETA = from_S( beta, *p, 1);
double RHO = *rho;
double SIG2 = *sig2;

int m = split( Xin, ID, X );
m = split( Yin, ID, Y );

matrix Hbb = newmat( *p, *p );
matrix Hbr = newmat( *p, 1 );
double Hss = 0.;
double Hrs = 0.;
double Hrr = 0.;

for ( int i = 0 ; i < m ; i++ )
	{
	int ni = X[i].rows();
	matrix ei = Y[i] - X[i] * BETA;
	matrix V = cs( RHO, ni );
	matrix S = SIG2 * V;
	matrix Sdor = SIG2*d_cs_d_rho(ni);
	matrix Sdos = V;
	matrix Si = sweep(S);
	Hbb = Hbb - transp(X[i])*Si*X[i];
	Hbr = Hbr - transp(X[i])*Si*Sdor*Si*ei;
	matrix eep = ei * transp(ei);
	Hrr = Hrr - .5*trace( Si*Sdor*Si*(2.*eep-S)*Si*Sdor );
	Hss = Hss - .5*trace( Si*Sdos*Si*(2.*eep-S)*Si*Sdos );
	Hrs = Hrs - .5*trace( Si*Sdor*Si*(2.*eep-S)*Si*Sdos ) +
		.5*trace( Si*( eep - S)*Si*d_cs_d_rho(ni) );
	}
to_S( Hbb, hbetabeta ); 
to_S( Hbr, hbetarho ); 
*hsig2sig2 = Hss; 
*hrhosig2 = Hrs;  
*hrhorho = Hrr;
return(0);
}


double mvnlik( matrix x, matrix y, matrix id, matrix beta, double sig2, double rho )
{
/* not fully general, assumes the multivariate structure depends */
/* only on the parameter rho */
/* should accept function determining the covariance structure */

matrix X[NCLUST];
matrix Y[NCLUST];
int M = split(x, id, X);
int M2 = split(y, id, Y);
int i;

double N = (double) y.rows();

double m2ll = 0.;

double t1 = N * log( 2. * 3.1415729  );

for ( i = 0 ; i < M ; i++ )
	{
	int ni = X[i].rows();
	matrix V = cs( rho, ni );
	matrix S = sig2 * V;
	matrix A = sweep(S);
	matrix mu = X[i] * beta;
	matrix ri = Y[i] - mu;
	matrix mt3 = (transp(ri) * A) * ri;
	double t3 = mt3.el(0,0);
	matrix mt2 =  symdet( A ) ;
	double t2 =  Log( mt2.el(0,0) );
	m2ll +=  -1.*t2 + t3;
	}
return m2ll+t1;
}

static void *sfunc;

extern "C" call_S( void*, long, char**, char**, long*, char**, long, void** ), 
	   S_alloc(int, unsigned);

/*
call_S_dim_omega_meta( func, &n, omptr, metaptr, 1,(int) q, (int)n );
*/

matrix call_S_dim_omega_meta( void** func, double* arg1, 
           double* arg2, double* arg3, int len1, int len2, int len3)
/* arg1 is dim of return mat, arg2 is omega, arg3 is meta */
{
int i, N;
char* corrmat_args[3];
char* corrmat_modes[3];
long corrmat_lengths[3];
void** corrmat_results;
double *ok;

N = (int) *arg1;
 
corrmat_args[0] = (char *) arg1;
corrmat_args[1] = (char *) arg2;
corrmat_args[2] = (char *) arg3;
 
corrmat_modes[0] = "double";
corrmat_modes[1] = "double";
corrmat_modes[2] = "double";
 
corrmat_lengths[0] =  len1;
corrmat_lengths[1] =  len2;
corrmat_lengths[2] =  len3;

corrmat_results = (void **) S_alloc( (int) (*arg1 * (*arg1)) , (unsigned)sizeof(double) );

sfunc = func[0];
 
call_S( sfunc, 3L, corrmat_args, corrmat_modes, 
	       corrmat_lengths, (char **) 0L, 1L, corrmat_results );

ok = (double *)corrmat_results[0];

matrix ans = newmat( N, N );
for ( i = 0 ; i < N ; i++ )
	for ( int j = 0 ; j < N ; j++ )
		{
		set_el(ans,i,j) = *ok++;
		}
return ans;
}

extern "C" eval_quadform_bdmat_intf( double* x, int* n, int* p, double* id, double* omega, int* q,
                    double* meta, void** func, double* qfp)
{
matrix X[NCLUST];
matrix META[NCLUST];
matrix Xin = from_S(x, *n, *p);
matrix IDin = from_S(id, *n, 1);
matrix OMEGAin = from_S(omega, *q, 1);
matrix METAin = from_S(meta, *n, 1);

int M = split(Xin, IDin, X);
int M2 = split( METAin, IDin, META);
 
matrix qf = newmat( Xin.cols(), Xin.cols() );

double *omptr = OMEGAin.mathead();
 
int i;
for (i = 0 ; i < M ; i++ )
        {
        int ni = X[i].rows();
	double dni = (double)ni;
	double *metaptr = META[i].mathead();
	matrix V = call_S_dim_omega_meta( func, &dni, omptr, metaptr, 1,(int)*q, (int)ni );
        matrix Vinv = sweep( V );
        qf = qf + (transp(X[i]) * Vinv * X[i] );
        }
to_S(qf, qfp);
return(0);
}

double rdec_mvnlik( matrix x, matrix y, matrix id, matrix meta, 
				   matrix beta, matrix omega, double sig2 )
{

matrix X[NCLUST];
matrix Y[NCLUST];
matrix META[NCLUST];
int M = split(x, id, X);
int M2 = split(y, id, Y);
int M3 = split(meta, id, META);
int i;

double N = (double) y.rows();

double m2ll = 0.;

double t1 = N * log( 2. * 3.1415729  );

for ( i = 0 ; i < M ; i++ )
	{
	int ni = X[i].rows();
	matrix V = dec( omega, META[i] );
	matrix S = sig2 * V;
	matrix A = sweep(S);
	matrix mu = X[i] * beta;
	matrix ri = Y[i] - mu;
	matrix mt3 = (transp(ri) * A) * ri;
	double t3 = mt3.el(0,0);
	matrix mt2 =  symdet( A ) ;
	double t2 =  log( mt2.el(0,0) );
	m2ll +=  -1.*t2 + t3;
	}
return m2ll+t1;
}

extern "C" hess_mvg_dec_intf( double* omega, double* beta, double* sig2, double* x,
				 double* y, double* id, double* s, int* n,
				 int* p, double* hessbeta_g, double* hessbeta_t, 
				 double* hesssig2, double* hess_sig2_g,
				 double* hess_sig2_t, double* hessomega )
{
matrix X[NCLUST];
matrix Y[NCLUST];
matrix META[NCLUST];

matrix Xin = from_S(x, *n, *p);
matrix Yin = from_S(y, *n, 1);
matrix ID = from_S(id, *n, 1);
matrix METAin = from_S(s, *n, 1);
matrix BETA = from_S( beta, *p, 1);
double SIG2 = *sig2;
matrix OMEGA = from_S( omega, 2, 1 );

int M = split(Xin, ID, X);
int M2 = split(Yin, ID, Y);
int M3 = split(METAin, ID, META);

double hgg = 0.;
double hgt = 0.;
double htt = 0.;
double hss = 0.;
double hsg = 0.;
double hst = 0.;
matrix hbg = newmat(*p,1);
matrix hbt = newmat(*p,1);

for ( int i = 0 ; i < M ; i++ )
	{
        int ni = X[i].rows();
	matrix ei = Y[i] - X[i] * BETA;
	matrix S = SIG2 * dec( OMEGA, META[i] );
	matrix dds = dec( OMEGA, META[i] );
	matrix iS = sweep(S);
	matrix tmp = iS*(2.*ei*transp(ei)-S)*iS;
	matrix tmp2 = iS*(ei*transp(ei)-S)*iS;
	matrix ddg = SIG2*d_dec_d_gamma( OMEGA, META[i] );
	matrix ddt = SIG2*d_dec_d_theta( OMEGA, META[i] );
	hbg = hbg - transp(X[i])*iS*ddg*iS*ei;
	hbt = hbt - transp(X[i])*iS*ddt*iS*ei;
	hss += -.5*trace( iS*dds*tmp*dds ) ;
	hsg += -.5*trace( iS*dds*tmp*ddg ) + .5*trace(1./SIG2 * tmp2 * ddg );
	hst += -.5*trace( iS*dds*tmp*ddt ) + .5*trace( 1./SIG2 *tmp2 * ddt );
	hgg += -.5*trace( iS*ddg*tmp*ddg ) + .5*trace( tmp2 * SIG2* d2_dec_d_gamma2( OMEGA, META[i] ));
	htt += -.5*trace( iS*ddt*tmp*ddt ) + .5*trace( tmp2 *  SIG2*d2_dec_d_theta2( OMEGA, META[i] ));
	hgt += -.5*trace( iS*ddt*tmp*ddg ) + .5*trace( tmp2 *  SIG2*d2_dec_d_gamma_d_theta( OMEGA, META[i] ));
	}
to_S( hbg, hessbeta_g );
to_S( hbt, hessbeta_t );
*hess_sig2_g = hsg;
*hess_sig2_t = hst;
*hesssig2=hss;
*hessomega=hgg;
*(hessomega+1)=hgt;
*(hessomega+2)=hgt;
*(hessomega+3)=htt;
return(0);
}



