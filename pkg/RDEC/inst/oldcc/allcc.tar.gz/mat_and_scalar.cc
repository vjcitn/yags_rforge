#include "MC++.h"

jmp_buf mcpp_env;

class mat_and_scalar
     {
     public:
        matrix mat;
        double scalar;

        mat_and_scalar();
        ~mat_and_scalar();

        mat_and_scalar(mat_and_scalar&);
        mat_and_scalar(matrix&,double);
     };

mat_and_scalar::mat_and_scalar()
     {
     mat = newmat(0,0);
     scalar=0.;
     }

mat_and_scalar::~mat_and_scalar()
     {
     mat = newmat(0,0);
     scalar=0.;
     }

mat_and_scalar::mat_and_scalar(mat_and_scalar& in)
     {
     mat = in.mat;
     scalar = in.scalar;
     }

mat_and_scalar::mat_and_scalar(matrix& inmat, double inscalar)
     {
     mat = inmat;
     scalar = inscalar;
     }


