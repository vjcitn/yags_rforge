/* @(#) matread.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: matread.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  MATREAD_FAIL_CANT_OPEN 47
#define  MATREAD_FAIL_NOT_RECT 48

#ifndef FOR_S
matrix matread(char *s)  // the problem with loading matrices is that  /* FUNCTION */
	{		// you don't know in advance how much memory
	int inword = 0;	// to allocate, and a buffer-growing strategy
	int nl = 0 ;	// is probably less efficient then a quick pass
	int nw = 0 ;	// to count "words"
	int nc = 0 ;
	char c;
	filebuf sfile;

	if ( sfile.open( s , input ) == 0 )
		{
		error_signal(mcpp_env, MATREAD_FAIL_CANT_OPEN);
		}
	istream from(&sfile);	

	while ( from.get(c) )
	{
		if (c == '\n') ++nl;
		if (c == ' ' || c == '\n' || c == '\t')
			inword = 0;
		else if (inword == 0)
		{
			inword = 1;
			++nw;
		}
	}
	/* now i have number of lines and number of tokens */

	if ( nw%nl != 0 )
		{
		error_signal(mcpp_env, MATREAD_FAIL_NOT_RECT);
		}

	sfile.close(); 		 // rewind
	sfile.open( s, input );  // reopen 
	istream from2(&sfile);	
	matrix tmp;
/*	tmp.nrows = nl;
	tmp.ncols = nw/nl;
	tmp.data = new double[ nw ];  */
	tmp = newmat( nl, nw/nl);
	from2 >>  tmp;		// now use the matrix read from stream
	return tmp;
}
#endif
