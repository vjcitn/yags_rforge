#include "MC++.h"

jmp_buf mcpp_env;

extern "C" yag(double*);

int yag( double* x )
{
printf("%lf\n",*x);
return(0);
}


main()
{
matrix X = matread("X");

yag(X.mathead());
matdump(transp(X));
}
