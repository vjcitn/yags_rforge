/* @(#) newmat.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: newmat.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix newmat(int i, int j ) // return allocated matrix  /* FUNCTION */
{
matrix x;
x.nrows = i;
x.ncols = j;
x.data = new double[ i*j ];
for ( int k = 0 ; k < i*j ; k++ )
	x.data[k] = 0.0;
return x;
}
