
/* @(#) cluscount.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: cluscount.c (c) V. Carey, ver. %I% , %D%";

/* cluscount -- returns integer length of run length encoding */

#include "MC++.h"
#define  CLUSCNT_FAIL_SPLIT_ERR 5

int cluscount( matrix& disc )
{
if (disc.cols() != 1)
	{
	error_signal(mcpp_env, CLUSCNT_FAIL_SPLIT_ERR);
	}

int k = 0;

#define MEL( a, b, c ) a.el( b, c )

int istart = (int)MEL( disc , 0 , 0 );
int start = 0;
int end = 0;
for ( int i = 1 ; i <= disc.rows() ; i++ )
        {
        if (( MEL( disc , i, 0 ) != istart ) ||
                        i == (disc.rows() ) )
                {
                k++;
                start = end+1;
                istart = (int)MEL( disc, i, 0 );
                }
        if (start < disc.rows() ) end++ ;
        }
/* DOES NOT CLEAN */
return k;
}

