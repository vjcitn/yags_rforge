
/* @(#) minuseq.cc 1.2 94/11/14 */
/* %P% */
/* /home/camacs/carey/PROGRAMMING/ports/gee2/MC++DIST9%I%/SCCS/s.minuseq.cc */
static char SCID[] = "@(#) MC++: minuseq.cc (c) V. Carey, ver. 1.2 , 92/0%I%4 19:19:02";
#include "MC++.h"
#define  MINUSEQ_FAIL_DIM_AGRMNT 29

void operator-=(matrix& arg1, matrix& arg2)  /* FUNCTION */
	{

double *matlook;

	if ( ( arg1.nrows != arg2.nrows ) ||
	     ( arg1.ncols != arg2.ncols ) )
		{
#ifndef FOR_S
		cerr << " matrix-= encounters fatal error:\n";
		cerr << " matrix-=:  arg1 is ( " << arg1.nrows <<
				" x " << arg1.ncols << " ) \n";
		cerr << " matrix-=:  arg2 is ( " << arg2.nrows <<
				" x " << arg2.ncols << " ) \n";
		cerr << " matrix-=:  arg1 and arg2 must agree in dimensionality.\n";
		error_signal(mcpp_env, MINUSEQ_FAIL_DIM_AGRMNT);
#else
		fprintf( stderr, "MC++: -= encounters improp dimensioned args. Die.\n");
		return;
#endif
		}

	matlook = arg1.mathead();

	for ( int i = 0; i < arg1.rows() ; i++ )
		{
		for ( int j = 0; j < arg1.cols() ; j++ )
			{
			*(matlook++) -= arg2.el(i,j) ;
			}
		}
	/* return arg1;  unnecessary */
	}
