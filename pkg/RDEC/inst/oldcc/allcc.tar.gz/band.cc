
/* @(#) band.c %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: band.c (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix band( matrix& inmat , int bandw )  /** band any matrix to bandwith bandw **/
{
	matrix tmp = inmat;
	for ( int i = 0 ; i < inmat.rows() ; i++ )
		{
		for ( int j = i+bandw ; j < inmat.cols() ; j++ )
			{
			set_el( tmp , i , j ) = (double)0.;
			if ( ( i < inmat.cols() ) && ( j < inmat.rows() ) )
				{
				set_el( tmp , j , i ) = (double)0.;
				}
			}
		}
	return tmp;
}

