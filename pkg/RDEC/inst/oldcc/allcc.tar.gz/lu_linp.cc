
/* @(#) lu_linp.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: lu_linp.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#include <math.h>

#define  LULINP_FAIL_NOT_SQR 21


extern "C" dgefa_( double*, int*, int*, int*, int*, int* );
extern "C" dgedi_( double*, int*, int*, int*, double*, double*,
			    int*, int* );
//extern "C" calloc( int, unsigned );

class ludcmp
     {
     public:
        matrix lumat;
        matrix permvec;
        double parity;

        ludcmp();
        ~ludcmp();

        ludcmp(ludcmp&);
        ludcmp(matrix&);
     };

ludcmp::ludcmp()
     {
     lumat = newmat(0,0);
     permvec = newmat(0,0);
     parity=0;
     }

ludcmp::~ludcmp()
     {
     lumat = newmat(0,0);
     permvec = newmat(0,0);
     parity=0;
     }

ludcmp::ludcmp(ludcmp& in)
     {
     lumat = in.lumat;
     permvec = in.permvec;
     parity = in.parity;
     }

ludcmp::ludcmp(matrix& a)
     {
     ludcmp null;
     int nr=a.rows();
     int nc=a.cols();
     if ( nr != nc )
       {
       error_signal(mcpp_env, LULINP_FAIL_NOT_SQR);
       }
     lumat = transp(a);  // for fortran compatibility
     permvec = newmat(nr,1);
     double* lpt = lumat.mathead();
     int* ipermvec = (int *)calloc( nr, (unsigned)sizeof(int) );
     int info = 0;
     int nargs = 5;
     dgefa_( lpt, &nr, &nr, ipermvec, &info, &nargs );//in place ludcmp in lumat
     lumat = transp(lumat);
     for (  int i = 0 ; i < nr ; i++ )
	set_el(permvec,i,0) = (double)*(ipermvec+i);
     }

matrix luinv( matrix& x )
	{
	matrix null;
	int nr = x.rows();
	int nc = x.cols();
        if ( nr != nc )
          {
          error_signal(mcpp_env, LULINP_FAIL_NOT_SQR);
          }
	ludcmp xlu = ludcmp(x);

	int* ipermvec = (int *)calloc(nr, (unsigned)sizeof(int));

	for ( int i = 0 ; i < nr ; i++ )
		*(ipermvec+i) = (int) xlu.permvec.el(i,0);

	matrix ans = transp(xlu.lumat); // fortran compatible

	double* ap = ans.mathead();

	double* det = (double *)calloc(2, (unsigned)sizeof(double));
	double* work = (double *)calloc(nr, (unsigned)sizeof(double));

	int job = 1;
	int nargs = 7;

	dgedi_( ap, &nr, &nr, ipermvec, det, work, &job, &nargs );

	return transp(ans);
	}
/*
main()
{
matrix x = matread("X");

ludcmp lux = ludcmp(x);

matrix b = transp(make_row(1.,0.,0.,));

//matrix invr = lubksolve( lux, b );

cout << lux.lumat;

cout << sweep(x)-luinv(x);
cout << sweep(x)*x;

cout << luinv(x)*x;
cout << x;
}
*/
