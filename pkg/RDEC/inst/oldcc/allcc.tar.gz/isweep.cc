/* @(#) isweep.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: isweep.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

void isweep( matrix& mat ) /* FUNCTION */

/* algorithm follows Goodnight, Amer Stat Aug 1979 p.149 */
/* isweep = IN PLACE (avoid copy) */

{

int k , j , i ;
double d , b, *out, *curtmp;

int tcol = mat.cols();
int trow = mat.rows();

out = mat.mathead();

for ( k = 0 ; k < trow ; k++ )   /* do 3 */

	{

	d = mat.el(k,k);

	for ( j = 0 ; j < trow ; j++ )   /*do 1 */

		{

		curtmp = out + j + k*(tcol);  /* address to load */
		*curtmp = mat.el(k,j) / d ;

		}   /* 1 */

	for ( i = 0 ; i < trow ; i++ )  /* do 2 */

		{

		if ( i != k ) 

			{

			b = mat.el(i,k);

			for ( j = 0 ; j < trow ; j++ )

				{

				curtmp = out + j + i*(tcol);
				*curtmp = mat.el(i,j) - b*mat.el(k,j); 

				}

			curtmp = out + k + i*(tcol);
			*curtmp = -b / d;

			}   /* end else: 2 */  

		}					/* 2 */	

		curtmp = out + k + k*(tcol);
		*curtmp = (double) 1.0 / d ;

	}  /* 3 */

}
