/* @(#) seq.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: seq.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#include <math.h>

#define  SEQ_FAIL_INFINITE_SEQ 37

matrix seq( int start, int end, int gran=1 )  /* FUNCTION */
{
if ( gran <= 0 && (start < end) ) error_signal(mcpp_env, SEQ_FAIL_INFINITE_SEQ);
if ( gran >= 0 && (start > end) ) error_signal(mcpp_env, SEQ_FAIL_INFINITE_SEQ);

int nel = ((int)(abs(end - start)/abs(gran))) + 1;

matrix tmp = newmat( 1 , nel );

double* head = tmp.mathead();

if ( start == end ) *head = (double) start;

else if ( start < end )
	{
	for ( ; start <= end ; *(head++) = (double) start , start+=gran );
	}
else	
	{
	for ( ; start >= end ; *(head++) = (double) start, start+=gran );
	}

return tmp;
}

