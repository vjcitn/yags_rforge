
/* @(#) concat.cc %I% %D% */
/* %P%*/
 
static char SCID[] = "@(#) MC++: concat.cc (c) V. Carey, ver. %I% , %D%";


#include "MC++.h"
#define  CONCAT_FAIL_ROW_AGRMNT 8
#define  CONCAT_FAIL_COL_AGRMNT 9

matrix operator||(matrix& arg1, matrix& arg2) /* horizontal concatenation */  /* FUNCTION */
	{
matrix concat;	
matrix null;
double *matlook;

	if ( arg1.rows() == 0 )   /* matrix uninitialized */
		{
		concat = arg2;
		return concat;
		}

	if  ( arg1.rows() != arg2.rows() )
		{
		error_signal(mcpp_env, CONCAT_FAIL_ROW_AGRMNT);
		}

	concat = newmat( arg1.rows() , arg1.cols()+arg2.cols() );
	matlook = concat.mathead();

	int a1r = arg1.rows();
	int a1c = arg1.cols();
	int a2c = arg2.cols();

	for ( int i = 0; i < a1r ; i++ )
		{
		for ( int j = 0; j < a1c + a2c ; j++ )
			{
			*(matlook++) = ( j < a1c ) ? arg1.el(i,j) : arg2.el(i,j-a1c);
			}
		}
	return concat;
	}

matrix operator/(matrix& arg1, matrix& arg2) /* vertical concatenation */  /* FUNCTION */
{
matrix null;
matrix concat;	
double *matlook;

	if ( arg1.cols() == 0 )
		{
		concat = arg2;
		return concat;
		}

	if  ( arg1.cols() != arg2.cols() )
		{
		error_signal(mcpp_env, CONCAT_FAIL_COL_AGRMNT);
		}

	concat = newmat( arg1.rows()+arg2.rows() , arg1.cols() );
	matlook = concat.mathead();

	int a1r = arg1.rows();
	int a2r = arg2.rows();
	int a1c = arg1.cols();
	int a2c = arg2.cols();

	for ( int i = 0; i < a1r+a2r ; i++ )
		{
		for ( int j = 0; j < a1c ; j++ )
			{
			*(matlook++) = ( i < a1r ) ? arg1.el(i,j) : arg2.el(i-a1r,j);
			}
		}
	return concat;
}
