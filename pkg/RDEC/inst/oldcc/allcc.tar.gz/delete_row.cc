/* @(#) delete_row.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: delete_row.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  DELROW_FAIL_NO_ROW 12

matrix delete_row( matrix& X, int i)  /* FUNCTION */
	/* i is row to delete , zerobased */
{
matrix result;
matrix null;
int ncop, nresel, skip;
double *resbase, *Xbase;

if (X.rows() <= 1)
	{
	error_signal(mcpp_env, DELROW_FAIL_NO_ROW);
	}

result = newmat( X.rows()-1, X.cols() );

nresel = result.rows() * result.cols() ;

skip = i*X.cols();

resbase = result.mathead();
Xbase = X.mathead();

for ( ncop = 0 ; ncop < nresel ; ncop++ )
	{
	if ( ncop == skip ) Xbase += X.cols();
	*resbase++ = *Xbase++ ;
	}

return result;
}

