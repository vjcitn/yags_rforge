#include "MC++.h"
#include <stdio.h>
#define  VEC2DIAG_FAIL_NEED_DIM1 46

/* @(#) vec2diag.cc 1.2 94/11/14 */
/* %P% */

/* /home/camacs/carey/PROGRAMMING/ports/gee2/MC++DIST9%I%/SCCS/s.vec2diag.cc */
static char SCID[] = "@(#) MC++: vec2diag.cc (c) V. Carey, ver. 1.2 , 92/0%I%4 19:21:49";

matrix vec2diag( matrix& x )
	{
	matrix null;
	if ( x.cols() != 1 && x.rows() != 1 )
		{
		fprintf(stderr,"MC++: vec2diag: need arg with 1 row or 1 col\n");
#ifndef FOR_S
		error_signal(mcpp_env, VEC2DIAG_FAIL_NEED_DIM1);
#else
		return(null);
#endif
		}
	if ( x.rows() == 1 ) x = transp(x);

	matrix out = newmat( x.rows(), x.rows() );

	for ( int i = 0 ; i < x.rows() ; i++ )
		{
		set_el( out, i, i) = x.el(i,0);
		}
	return out;
	}
