/* @(#) to_S.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: to_S.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

void to_S( matrix& inmat , double* target ) /* FUNCTION */
{
double *dummy;

dummy = target;

for ( int i = 0 ; i < inmat.cols() ; i++ )
	{
	for ( int j = 0 ; j < inmat.rows() ; j++ )
		{
		*(dummy++) = inmat.el(j,i);
		}
	}
}

