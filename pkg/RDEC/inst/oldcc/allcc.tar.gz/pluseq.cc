/* @(#) pluseq.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: pluseq.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  PLUSEQ_FAIL_DIM_AGRMNT 33


void operator+=(matrix& arg1, matrix& arg2)  /* FUNCTION */
	{

double *matlook;
	if ( arg1.rows() == 0 ) 
		{
		arg1 = arg2;
		return;
		}

	if ( ( arg1.rows() != arg2.rows() ) ||
	     ( arg1.cols() != arg2.cols() ) )
		{
		error_signal(mcpp_env, PLUSEQ_FAIL_DIM_AGRMNT);
		}

	matlook = arg1.mathead();

	for ( int i = 0; i < arg1.rows() ; i++ )
		{
		for ( int j = 0; j < arg1.cols() ; j++ )
			{
			*(matlook++) += arg2.el(i,j) ;
			}
		}
	/* return arg1;  unnecessary */
	}
