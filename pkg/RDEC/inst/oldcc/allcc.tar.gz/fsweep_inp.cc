/* @(#) fsweep_inp.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: fsweep_inp.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#include <math.h>

#define  FSWEEPINP_FAIL_TOO_SMALL 18
#define  FSWEEPINP_FAIL_NOT_SEMIDEF 19
#define  FSWEEPINP_FAIL_TRIANGLE 20

extern "C" void * syminv_intf( double* , int* , int* ,
				double* , double* , int*, int* );

void untriangularize_inp( matrix& , matrix& );

/* fsweep_inp -- calls the AS syminv for fast inversion of symm pd mat */
/* perform in-place inversion */

void fsweep_inp( matrix& mat ) /* FUNCTION */
{

int n = mat.cols();
int nn = n*(n+1)/2;

matrix tri = lower_triangularization( mat );

//matrix res = newmat(nn,1);

matrix scratch = newmat(n+1,1);

double* a = tri.mathead();
double* c = a;  /* true in-place */
double* w = scratch.mathead();
int nullty, ifault;

syminv_intf( a , &n , &nn , c , w , &nullty , &ifault );

switch( ifault )
	{
	case 1:
		error_signal(mcpp_env, FSWEEPINP_FAIL_TOO_SMALL);
		break;
	case 2:
		error_signal(mcpp_env, FSWEEPINP_FAIL_NOT_SEMIDEF);
		break;
	default:
		break;
	}

untriangularize_inp( tri , mat );
}

matrix lower_triangularization( matrix& mat )
{

int n = mat.cols();
int nn = n*(n+1)/2;

double *target, *source;

matrix tri = newmat(nn,1);

target = tri.mathead();
source = mat.mathead();

int j = 0;
int k = n;
for ( int i = 0 ; i < nn ; i++ )
	{
	if ( ( j>0 ) && (( (j-1) % (n+1) ) == 0) ) 
		{
		k--;
		j+=k;
		}
	*(target+i) = *(source+j);
	j++;
	}
return tri;
}

void untriangularize_inp( matrix& mat , matrix& outm )
{
int nn = length(mat);
double dnn = (double)nn;
int n = (int)((sqrt((double)1.+8*dnn) -1.)/2.);
if ( n != outm.cols() )
	{
	error_signal(mcpp_env, FSWEEPINP_FAIL_TRIANGLE);
	}
double* source = mat.mathead();
double* outp = outm.mathead();
int j = 0;
int k = n;
for ( int i = 0 ; i < n*n ; i++ )
	{
	*(outp+i) = 0.;
	}
	
for ( i = 0 ; i < nn ; i++ )
	{
	if ( ( j>0 ) && (( (j-1) % (n+1) ) == 0) ) 
		{
		k--;
		j+=k;
		}
	*(outp+j) = *(source+i);
	j++;
	}
	/* now lower tri has been formed */
for ( i = 0 ; i < n ; i++ )
	{
	for ( j = i+1 ; j < n ; j++ )
		{
		set_el( outm , i , j ) = outm.el(j,i);
		}
	}
}
		

