/* @(#) matmath.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: matmath.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#include <math.h>

#define  MATMATH_FAIL_NEG_MATRIX 24

matrix matlog( matrix& mat )  /* someday, log will just be overloaded.  not now */  /* FUNCTION */
{
matrix null;
double *load;
matrix tmp;

tmp = newmat( mat.rows() , mat.cols() );

load = tmp.mathead();

for ( int i = 0 ; i < mat.rows() * mat.cols() ; i++ )
	{
	if ( mat.data[i] > 0. )
		*(load++) = log( mat.data[i] );
	else
		{
		error_signal(mcpp_env, MATMATH_FAIL_NEG_MATRIX);
		}
	}
	return tmp;
}

matrix matexp( matrix& mat )  /* FUNCTION */
{
double *load;
matrix tmp;

tmp = newmat( mat.rows() , mat.cols() );

load = tmp.mathead();

for ( int i = 0 ; i < mat.rows() * mat.cols() ; i++ )
	{
	*(load++) = exp( mat.data[i] );
	}
return tmp;
}

matrix matsqrt( matrix& mat )  /* FUNCTION */
{
double *load;
matrix tmp;

tmp = newmat( mat.rows() , mat.cols() );

load = tmp.mathead();

for ( int i = 0 ; i < mat.rows() * mat.cols() ; i++ )
	{
	*(load++) = sqrt( mat.data[i] );
	}
return tmp;
}


matrix matabs( matrix& mat )  /* FUNCTION */
{
double *load;
matrix tmp;

tmp = newmat( mat.rows() , mat.cols() );

load = tmp.mathead();

for ( int i = 0 ; i < mat.rows() * mat.cols() ; i++ )
	{
	*(load++) = fabs( mat.data[i] );
	}
return tmp;
}

double max( matrix& in )  /* FUNCTION */
	{
	double mx = in.el(0,0);
	for ( int i = 0 ; i < in.rows() ; i++ )
		{
		for ( int j = 0 ; j < in.cols() ; j++ )
			{
			if (in.el(i,j) > mx ) mx = in.el(i,j);
			}
		}
	return mx;
	}

double min( matrix& in )  /* FUNCTION */
	{
	double min = in.el(0,0);
	for ( int i = 0 ; i < in.rows() ; i++ )
		{
		for ( int j = 0 ; j < in.cols() ; j++ )
			{
			if (in.el(i,j) < min ) min = in.el(i,j);
			}
		}
	return min;
	}

double elsum( matrix& mat )  /* FUNCTION */
{
double sum = 0.;
for ( int i = 0 ; i < mat.rows() * mat.cols() ; i++ )
	{
	sum +=  mat.data[i] ;
	}
return sum;
}
