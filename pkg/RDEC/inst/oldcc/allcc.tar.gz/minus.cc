/* @(#) minus.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: minus.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  MINUS_FAIL_DIM_AGRMNT 28

matrix operator-(matrix& arg1, matrix& arg2)  /* FUNCTION */
	{
matrix diff;	
double *matlook;

	if ( ( arg1.rows() != arg2.rows() ) ||
	     ( arg1.cols() != arg2.cols() ) )
		{
		error_signal(mcpp_env, MINUS_FAIL_DIM_AGRMNT);
		}

	diff = newmat( arg1.rows() , arg1.cols() );
	matlook = diff.mathead();

	for ( int i = 0; i < arg1.rows() ; i++ )
		{
		for ( int j = 0; j < arg1.cols() ; j++ )
			{
			*(matlook++) = arg1.el(i,j) - arg2.el(i,j);
			}
		}
	return diff;
	}

matrix operator-(double arg1, matrix& arg2)  /* FUNCTION */
	{
	matrix sum = newmat( arg2.rows(), arg2.cols() );

	double* matlook = sum.mathead();

	for ( int i = 0; i < arg2.rows() ; i++ )
		{
		for ( int j = 0; j < arg2.cols() ; j++ )
			{
			*(matlook++) = arg1 - arg2.el(i,j);
			}
		}
	return sum;
	}
