/* @(#) fmatdump.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: fmatdump.cc (c) V. Carey, ver. %I% , %D%";

/* program writes matrix to file */

#include "MC++.h"
#include <stdio.h>

void fmatdump(const char* filename, matrix& arg1)
{
FILE *fp;

fp = (FILE *)fopen(filename,"w");
for ( int i = 0 ; i < arg1.rows() ; i++ )
	{
	for ( int j = 0 ; j < arg1.cols() ; j++ )
		{
		fprintf(fp,"%.6f  ", arg1.el( i , j ) );
		}
	fprintf(fp,"\n");
	}
}
