
/* @(#) blast_time.cc %I% %D% */
/* %P% */

/* blast_time will write out the wall clock time next to a */
/* string constant useful for signposting slow-running programs */
/* all it does is I/O, so we leave the printf */
 
static char SCID[] = "@(#) MC++: blast_time.cc (c) V. Carey, ver. %I% , %D%";

#include <stdio.h>
#include <sys/time.h>
#include <string.h>

extern "C" calloc(const int, unsigned);

void blast_time(const char* instr)
{
struct timeval *tp;
struct timezone *tzp;
char timestr[30];
long clock;

tp = (struct timeval *)calloc(1, (unsigned)sizeof(struct timeval));
tzp = (struct timezone *)calloc(1, (unsigned)sizeof(struct timezone));

if ( gettimeofday( tp, tzp ) != -1 )
	clock = tp->tv_sec;

strcpy(timestr,ctime(&clock));
printf("%s %s",instr,timestr);
}
	
