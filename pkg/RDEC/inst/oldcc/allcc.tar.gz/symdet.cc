/* @(#) symdet.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: symdet.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix symdet( matrix& mat ) /* FUNCTION */

/* algorithm follows Goodnight, Amer Stat Aug 1979 p.149 */

{

int k , j , i ;
double d , b, *in, *out, *curtmp, detsc = 1.;
matrix temp, detmat;

temp = newmat(mat.rows(),mat.cols());
detmat = newmat( 1 , 1 );

in = mat.mathead();
out = temp.mathead();

for ( i = 0 ; i < mat.rows()*mat.cols() ; /* copy to out */
		*(out++) = *(in++), i++ )
		;

out = temp.mathead();
detsc = temp.el(0,0);

for ( k = 0 ; k < mat.rows() ; k++ )   /* do 3 */

	{

	d = temp.el(k,k);

	for ( j = 0 ; j < mat.rows() ; j++ )   /*do 1 */

		{

		curtmp = out + j + k*(temp.cols());  /* address to load */
		*curtmp = temp.el(k,j) / d ;

		}   /* 1 */

	for ( i = 0 ; i < mat.rows() ; i++ )  /* do 2 */

		{

		if ( i != k ) 

			{

			b = temp.el(i,k);

			for ( j = 0 ; j < mat.rows() ; j++ )

				{

				curtmp = out + j + i*(temp.cols());
				*curtmp = temp.el(i,j) - b*temp.el(k,j); 

				}

			curtmp = out + k + i*(temp.cols());
			*curtmp = -b / d;

			}   /* end else: 2 */  

		}					/* 2 */	

		curtmp = out + k + k*(temp.cols());

			
		if ( k <  ( mat.rows() -1 ) )
			detsc = detsc * temp.el( k+1 , k+1 ) ;

		*curtmp = (double) 1.0 / d ;

	}  /* 3 */

curtmp = detmat.mathead();
*curtmp = detsc;
return detmat;

}
