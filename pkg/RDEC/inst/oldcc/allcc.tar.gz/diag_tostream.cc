
/* @(#) diag_tostream.cc 1.2 94/11/14 */
/* %P% */
/* /home/camacs/carey/PROGRAMMING/ports/gee2/MC++DIST9%I%/SCCS/s.diag_tostream.cc */
static char SCID[] = "@(#) MC++: diag_tostream.cc (c) V. Carey, ver. 1.2 , 92/0%I%4 19:19:21";
#include "MC++.h"

#ifndef FOR_S
ostream& operator<<(ostream&s , diag_matrix& arg1)  /* FUNCTION */
	{
	for ( int i = 0 ; i < arg1.rows() ; i++ )
		{
		for ( int j = 0 ; j < arg1.rows() ; j++ )
			{
			s << form("%.4f  ", arg1.el( i , j ) );
			}
		s << "\n";
		}
	return s;
	}
#endif
