/* @(#) transp.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: transp.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix transp( matrix& base )  /* note -- a preferred way is to dynamically */ /* FUNCTION */
				/* modify the operation of el */
{
matrix x;
double *look, *load;
int i, j;

x = newmat( base.cols() , base.rows() );
load = x.mathead();
look = base.mathead();
for ( i = 0 ; i < x.rows() ; i++ )
	{
	for ( j = 0 ; j < x.cols() ; j++ )  /* load row-major */
		{
		*(load++) = base.el(j,i);
		}
	}
return x;
}
matrix operator++( matrix& arg )
	{
	return( transp(arg) );
	}
