
#include "MC++.h"
#include <setjmp.h>

jmp_buf mcpp_env;
int errcode;

main()
{
while(!( errcode = setjmp(mcpp_env)))
{
matrix x = matread("X");
 
cout << luinv(x);
return(0);
}
cout << errcode;
}
/*
//ludcmp lux = ludcmp(x);
 
matrix b = transp(make_row(1.,0.,0.,));
 
//matrix invr = lubksolve( lux, b );
 
cout << lux.lumat;
 
cout << sweep(x)-luinv(x);
cout << sweep(x)*x;
 
cout << luinv(x)*x;
cout << x;
return(0);
}
cout << errcode;
}
*/
