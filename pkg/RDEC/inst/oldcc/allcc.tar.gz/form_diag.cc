/* @(#) form_diag.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: form_diag.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  FORM_FAIL_NOT_VECT 15


matrix form_diag( matrix& invec )
{
matrix null;
if ( (invec.rows() > 1) && (invec.cols() > 1) )
	{
	error_signal(mcpp_env, FORM_FAIL_NOT_VECT);
	}

int dim = invec.rows() * invec.cols();
matrix curr = newmat( dim, dim );

for ( int i = 0 ; i < dim ; i++ )
	{
	set_el( curr , i , i ) = invec.el(0,i);
	}
return curr;
}
