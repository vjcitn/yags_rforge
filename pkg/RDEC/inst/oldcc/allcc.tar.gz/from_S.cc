
/* @(#) from_S.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: from_S.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix from_S( double* x , int xrow, int xcol )  /* FUNCTION */
{
matrix tmp = newmat( xcol, xrow );
double *head = tmp.mathead();

for ( int j = 0 ; j < xrow * xcol ; j++ )
	{
	*(head++) = *(x++);
	}
tmp = transp(tmp);
return tmp;
}
