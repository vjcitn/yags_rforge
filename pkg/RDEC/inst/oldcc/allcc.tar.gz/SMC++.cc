/* @(#) %M% %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: SMC++.c (c) V. Carey, ver. %I% , %D%";


void SMplpl(){}
