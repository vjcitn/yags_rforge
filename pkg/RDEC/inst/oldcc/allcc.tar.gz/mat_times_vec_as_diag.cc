/* @(#) mat_times_vec_as_diag.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: mat_times_vec_as_diag.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  MATTIMES_FAIL_NOT_COLVEC 22
#define  MATTIMES_FAIL_DIM_AGRMNT 23


matrix mat_times_vec_as_diag( matrix& mat, matrix& dg )
	{
	matrix null;
	if ( dg.cols() != 1 )
		{
		error_signal(mcpp_env, MATTIMES_FAIL_NOT_COLVEC);
		}
	if ( mat.cols() != dg.rows() )
		{
		error_signal(mcpp_env, MATTIMES_FAIL_DIM_AGRMNT);
		}

	matrix ret = newmat( mat.rows(), mat.cols() );

	for ( int j = 0 ; j < mat.cols() ; j++ )
		{
		for ( int i = 0 ; i < mat.rows() ; i++ )
			{
			set_el( ret, i, j ) = mat.el(i,j)*dg.el(j,0);
			}
		}
	return ret;
	}
	
