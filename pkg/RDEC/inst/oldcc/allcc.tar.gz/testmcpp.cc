#include "MC++.h"
#include <setjmp.h>

jmp_buf mcpp_env;
int errcode;

main()
{
while(!( errcode = setjmp(mcpp_env)))
	{
matrix x = matread("X");
matrix y = matread("Y");
//longjmp(mcpp_env,4);
cout << "hello" << '\n';
//blast_time("abc");

//cout << band(x,1);
//cout << extract_diag(x);
cout << Msort_on_col(x,0);
//cout << (x || y);
return(0);
}
cout << "error " << errcode ;
}
