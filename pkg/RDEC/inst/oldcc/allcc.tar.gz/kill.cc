/* @(#) kill.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: kill.cc (c) V. Carey, ver. %I% , %D%";


#include "MC++.h"

void kill( matrix& mat )
	{
	delete mat.data;
	mat.ncols = 0;
	mat.nrows = 0;
	}

