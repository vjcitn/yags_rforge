/* @(#) trace.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: trace.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

double trace( matrix& mat )
	{
	double tmp = 0.;
	for ( int i = 0 ; i <  mat.rows() ; i++ )
		tmp += mat.el(i,i);
	return tmp;
	}
