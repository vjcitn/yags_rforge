/* @(#) %M% %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: %M% (c) V. Carey, ver. %I% , %D%";


#include "MC++.h"
#define  ROWMUL_FAIL_NOT_COLVEC 34
#define  ROWMUL_FAIL_DIM_AGRMT 35


matrix rowmul( matrix& vec , matrix& mat )   /** mult els of a cul vector across  **/
{						/** rows of a similarly row-dimmed mat **/
	matrix null;
	matrix result = newmat( mat.rows() , mat.cols());
	if ( vec.cols() != 1 )
		{
		error_signal(mcpp_env, ROWMUL_FAIL_NOT_COLVEC);
		}
	if ( vec.rows() != mat.rows() )
		{
		error_signal(mcpp_env, ROWMUL_FAIL_DIM_AGRMT);
		}
	for ( int i = 0 ; i < vec.rows() ; i++ )
		{
		for ( int j = 0 ; j < mat.cols() ; j++ )
			{
			set_el( result , i , j ) = mat.el(i,j) * vec.el(i,0);
			}
		}
	return result;
}

