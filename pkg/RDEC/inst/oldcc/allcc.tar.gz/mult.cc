/* @(#) mult.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: mult.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  MULT_FAIL_DIM_AGRMNT 30

matrix operator*(matrix& arg1, matrix& arg2)  /* FUNCTION */
{
matrix prod; 
double *matlook;

	if  ( arg1.cols() != arg2.rows() )
		{
		error_signal(mcpp_env, MULT_FAIL_DIM_AGRMNT);
		}

	prod = newmat( arg1.rows() , arg2.cols() );

	matlook = prod.mathead();
	double* a1head = arg1.mathead();
	double* a2head = arg2.mathead();
	double* a1cur = a1head;
	double* a2cur = a2head;

	int a2c = arg2.cols();
	int a1c = arg1.cols();
	double* a2h = arg2.mathead();

	for ( int j = 0; j < prod.rows() ; j++ )
		{
		for ( int i = 0; i < prod.cols() ; i++ )
			{
			a1cur = a1head;
			a2cur = a2head;
			for ( int k = 0 ; k < arg2.rows() ; k++ )
				{
				*(matlook) += *(a1cur++) * *a2cur;
				a2cur += a2c;
				}
			matlook++;
			a2head++;
			}
		a1head += a1c;
		a2head = a2h;
		}
	return prod;
}
matrix operator*(double arg1, matrix& arg2)  /* FUNCTION */
{
matrix prod;
double *matlook;

prod = newmat( arg2.rows(), arg2.cols() );
matlook = prod.mathead();

for ( int i = 0 ; i < arg2.rows()*arg2.cols() ; i++ )
	{
	*(matlook+i) = arg1 * arg2.data[i] ;
	}
return prod;
}
matrix operator*(matrix& arg1, double arg2)  /* FUNCTION */
{
return arg2*arg1;
}
