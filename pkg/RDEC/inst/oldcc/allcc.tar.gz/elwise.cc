/* @(#) elwise.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: elwise.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  ELWISE_FAIL_DIM_AGRMNT 13
         
matrix operator*=(matrix& arg1, matrix& arg2) /* el-wise mult!!! */  /* FUNCTION */
	{
matrix prod;	
double *matlook;

	if  (( arg1.rows() != arg2.rows() ) || ( arg1.cols() != arg1.cols()))
		{
		error_signal(mcpp_env, ELWISE_FAIL_DIM_AGRMNT);
		}

	prod = newmat( arg1.rows() , arg1.cols() );
	matlook = prod.mathead();
	double* loo1 = arg1.mathead();
	double* loo2 = arg2.mathead();


	for ( int i = 0; i < arg1.rows()*arg1.cols() ; i++ )
		{
		*(matlook++) = *(loo1++) * *(loo2++);
		}
return prod;
}
matrix operator/=(matrix& arg1, matrix& arg2) /* el-wise div!!! */  /* FUNCTION */
	{
matrix quot;	
double *matlook;

	if  (( arg1.rows() != arg2.rows() ) || ( arg1.cols() != arg1.cols()))
		{
		error_signal(mcpp_env, ELWISE_FAIL_DIM_AGRMNT);
		}

	quot = newmat( arg1.rows() , arg1.cols() );
	matlook = quot.mathead();
	double* loo1 = arg1.mathead();
	double* loo2 = arg2.mathead();


	for ( int i = 0; i < arg1.rows()*arg1.cols() ; i++ )
		{
		*(matlook++) = *(loo1++) / *(loo2++);
		}
return quot;
}
