/* @(#) Msort_on_col.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) Msort_on_col.cc %I% %D%";
 
#include "MC++.h"

          static    int Mcpp_compare(const void *i, const void *j)
          {
// this is explicit type conversion (see pp52-53 of stroustrup 2e
// necessary for proper behavior of stdlib.h compliant compare in qsort
		double* x = (double*) i;
		double* y = (double*) j;
//               cout << *x;
               int out = 0;
		if (*x < *y) out = -1;
		else if (*x > *y) out = 1;
		return out;
          }
 

matrix Msort_on_col( matrix& x , int col )   /* col zerobased */
{
matrix null;
if ( col > x.cols() )
	{
#ifndef FOR_S
	error_signal(mcpp_env, MSORT_FAIL_NO_COL);
#else
	return(null);
#endif
	}
matrix sortcol = x.submat(0,mat11(col));
matrix tmp = sortcol || x;
int wid = tmp.cols() * 8;
int nel = x.rows();
double* base = tmp.mathead();
// this works because compare function looks only at first double of each
// record, the place where we stuck the key column 
qsort( (char *)base , nel , wid , Mcpp_compare );
// return matrix after key column removed
tmp = tmp.submat(0,seq(1,tmp.cols()-1,1));
return tmp;
}


