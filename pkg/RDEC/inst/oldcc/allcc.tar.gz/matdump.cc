
/* @(#) matdump.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: matdump.cc (c) V. Carey, ver. %I% , %D%";

/* I/O routine, printf allowed */

/* matdump -- print out a MATRIX assuming doubles */
/* must observe meaning of DO_PR, which is fprintf(of, for fmatdump */

#include "MC++.h"
#include <math.h>

#define DO_PR printf(   
/* ) */
#define N_COLS 8

void matdump(matrix& matarg)  /* FUNCTION */

{

double * curel;
int outtok = 0, out2=0, el_deliver;

DO_PR "\nmatdump: %d by %d matrix \n\n",matarg.rows(),
			matarg.cols());

if ( matarg.cols() < N_COLS )   /* narrow enough to print line by line */
	{
	for ( curel = matarg.mathead(); 
		curel < matarg.mathead() + (matarg.rows() * matarg.cols()) ; curel++ )
		{
		DO_PR (fabs(*curel)<.00001) ? "%le%c" : "%lf%c",*curel, 
	  	( outtok++%matarg.cols() == matarg.cols()-1 ) ?
			 '\n' : ' ' );
		}
	}

else			  /* needs to be broken up */
	{
	el_deliver = 0;   /* count elements from current ROW printed out */

	for ( curel = matarg.mathead();        /* for every element */
		curel < matarg.mathead() + ( matarg.rows() * matarg.cols() ) ; curel++ )
		{
		el_deliver= el_deliver+1;
		if (!( el_deliver % (N_COLS-1) ))   /* just tripped N_COLS, so <NL> and tab */
			{
			DO_PR "\n\t");
			}
		DO_PR (fabs(*curel)<.00001) ? "%le " : "%lf ",*curel);
		if (!( el_deliver % (matarg.cols()) ))  /* tripped last COL */
			{			       /* so reset and <NL> */
			el_deliver = 0; 
			DO_PR "\n");
			}
		}
	}

}
