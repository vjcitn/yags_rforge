/* common -- get common elements of two vectors */
/* @(#) common.cc 1.2 94/11/14 */
/* %P%*/

/* /home/camacs/carey/PROGRAMMING/ports/gee2/MC++DIST9%I%/SCCS/s.common.c */
static char SCID[] = "@(#) MC++: common.cc (c) V. Carey, ver. 1.2 , 92/0%I%4 19:21:37";


#include "MC++.h"
#define  COMMON_FAIL_DIM_ERR 6
#define  COMMON_FAIL_NEED_VECT 7

matrix common( matrix& mat1, matrix& mat2 )
	{
matrix null;
	int m1r = mat1.rows();
	int m2r = mat2.rows();
	int m1c = mat1.cols();
	int m2c = mat2.cols();

	if ( m1r*m2r*m1c*m2c <= 0 ) return mat11(-99999.0);
	if ( mat1.rows()/mat2.rows() != 1 && mat1.cols()/mat2.cols() != 1 )
		{
		fprintf(stderr,"MC++: common -- args must agree on at least one dim.\n");
		fprintf(stderr,"MC++: common: arg1 is %d x %d , arg2 is %d x %d\n",mat1.rows(),mat1.cols(),mat2.rows(),mat2.cols());
#ifndef FOR_S
		error_signal(mcpp_env, COMMON_FAIL_DIM_ERR);
#else
		return(null);
#endif
		}
	if ( (mat2.rows() != 1 && mat2.cols() != 1 ) || (mat1.rows() != 1 && mat1.cols() != 1 ) )
		{
		fprintf(stderr,"MC++: common -- both args must be vecs.\nDies.");
		fprintf(stderr,"MC++: common: arg1 is %d x %d , arg2 is %d x %d\n",mat1.rows(),mat1.cols(),mat2.rows(),mat2.cols());
#ifndef FOR_S
		error_signal(mcpp_env, COMMON_FAIL_NEED_VECT);
#else
		return(null);
#endif
		}
	matrix tmp1 = mat1;
	matrix tmp2 = mat2;
	int transpd = 0;
	if ( mat1.rows() == 1 )   /* row-vec, must transpose */
		{
		tmp1 = mat1++;
		tmp2 = mat2++;
		transpd = 1;
		}
	tmp1 = Msort_on_col( tmp1 , 0 );
	tmp2 = Msort_on_col( tmp2 , 0 );
	int L2 = length( tmp2 );
	int L1 = length( tmp1 );
	matrix final = mat11((double)-99999.);
	int fcur = 0;
	for ( int i = 0 ; i < L2 ; i++ )
		{
		double test = tmp2.el(i,0);
		if ( test > tmp1.el(L1-1,0) ) break;  /* can't match */
		if ( i > 0 )
			{
			if ( test == tmp2.el(i-1,0)) continue; /* skip dups */
			}
		for ( int j = 0 ; j < L1 ; j++ )
			{
			if ( test == tmp1.el(j,0) ) /* match */
				{
				if ( (length(final) == 1 ) && 
					(final.el(0,0) < -99990. ) )
					  set_el(final,0,0) = test;
				else 
					{
					final = final / mat11(test);
					fcur++;
					}
				break;
				}
			if ( test < tmp1.el(j,0) ) /* tmp1 too big now */
				break;
			}
		}
	if (transpd ) return final++;
	return final;
	}
