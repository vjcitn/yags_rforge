/* @(#) toeplitz.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: toeplitz.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  TOEPLITZ_FAIL_DIM_AGRMNT 45

matrix toeplitz( matrix& in ) /* FUNCTION */
{
void plug( matrix&,  matrix&, int, int );
matrix toep, tin;
int n, p;
int inrows = in.rows();
int incols = in.cols();

if ( (inrows > incols) ? inrows % incols : incols % inrows ) // !=0
	{
	error_signal(mcpp_env, TOEPLITZ_FAIL_DIM_AGRMNT);
	}

if ( inrows > incols )   // n.p * p
	{
	p = incols;
	n = inrows/p;
	tin = in;
	}
else			// p * n.p
	{
	p = inrows;
	n = incols/p;
	tin = transp(in);   /* to permit plucking of boxes */
	}

toep = newmat( n*p, n*p );

for ( int i = 0 ; i < n ; i++ )
	{
	matrix tmp = rowseg( tin, i*p , p );  /* boxes plucked as rowsegs */

	if ( i == 0 )
		{
		for ( int j = 0 ; j < n ; j++ )
			{
			if ( inrows > incols )
				plug( tmp, toep, j*p, j*p );
			else
				plug( transp(tmp), toep, j*p, j*p );
			}
		}
	else
		{
		for ( int j = 0 ; j < n-i ; j++ )
			{
		/*	if ( inrows > incols )
				{ */
				plug( transp( tmp ), toep , j*p , (j+i)*p);
				plug(  tmp , toep , (j+i)*p , j*p);
				/* }
			else
				{
				plug(  tmp , toep , j*p , (j+i)*p);
				plug(  transp(tmp) , toep , (j+i)*p , j*p);
				} */
			}
		}
	}
return toep;
}


