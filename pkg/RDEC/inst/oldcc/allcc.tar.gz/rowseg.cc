#include "MC++.h"
#define  ROWSEG_FAIL_DIM_AGRMT 36

/* @(#) rowseg.cc 1.2 94/11/14 */
/* %P% */
/* /home/camacs/carey/PROGRAMMING/ports/gee2/MC++DIST9%I%/SCCS/s.rowseg.cc */
static char SCID[] = "@(#) MC++: rowseg.cc (c) V. Carey, ver. 1.2 , 92/0%I%4 19:19:10";

#ifdef FOR_S
#define exit(a) return(null)
#endif

matrix rowseg( matrix& base , int rowstart , int nrows )  /* FUNCTION */
{
matrix null;
matrix x;
double *look, *load;
int i, j;

if ( rowstart + nrows > base.rows() || rowstart > base.rows() )
	{
	error_signal(mcpp_env, ROWSEG_FAIL_DIM_AGRMT);
	}

x = newmat( nrows , base.cols() );
load = x.mathead();
look = base.mathead() + (rowstart)*base.cols();
for ( i = 0 ; i < nrows ; i++ )
	{
	for ( j = 0 ; j < base.cols() ; j++ )
		{
		*(load++) = *(look++);
		}
	}
return x;
}
