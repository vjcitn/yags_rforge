 
/* @(#) split.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: split.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  SPLIT_FAIL_NOT_COLVEC 38
#define  SPLIT_FAIL_DIM_AGRMNT 39
#define  SPLIT_FAIL_NO_POINTERS 40


/* first routine is obsolete, assumes that a matrix array[CONST] */
/* has been declared.  second routine just assigns to a matrix *array */
/* which need not be dimensioned in advance */


int split( matrix& mat , matrix& disc , matrix recv[] )    /* FUNCTION */

{
int i=0 , j=0 , k=0, start=0, end=0, len=1;
double istart;

if (disc.cols() != 1)
	{
	error_signal(mcpp_env, SPLIT_FAIL_NOT_COLVEC);
	}

if (disc.rows() != mat.rows())
	{
	error_signal(mcpp_env, SPLIT_FAIL_DIM_AGRMNT);
	}

k = 0 ;

istart = disc.el(0,0);

for ( i = 1 ; i <= disc.rows() ; i++ )
	{
	if ((  disc.el( i , 0 ) != istart ) || i == (disc.rows()) )
		{
		len = end - start + 1;
		recv[k] = rowseg( mat , start , len );
		k++;
		start = end + 1;
		istart =  disc.el( i , 0 );
		}
	if (start < disc.rows()) end++;
	}
return k;
}

matrix* split( matrix& mat , matrix& disc )    /* FUNCTION */

{
int i=0 , j=0 , k=0, start=0, end=0, len=1;
double istart;
matrix *recv;

if (disc.cols() != 1)
	{
	error_signal(mcpp_env, SPLIT_FAIL_NOT_COLVEC);
	}

if (disc.rows() != mat.rows())
	{
	error_signal(mcpp_env, SPLIT_FAIL_DIM_AGRMNT);
	}

k = 0 ;

int nclus = cluscount( disc );
if (!(recv = (matrix *)calloc( nclus, (unsigned)sizeof(class matrix))))
	{
	error_signal(mcpp_env, SPLIT_FAIL_NO_POINTERS);
	}

istart = disc.el(0,0);

for ( i = 1 ; i <= disc.rows() ; i++ )
	{
	if ((  disc.el( i , 0 ) != istart ) || i == (disc.rows()) )
		{
		len = end - start + 1;
		recv[k] = rowseg( mat , start , len );
		k++;
		start = end + 1;
		istart =  disc.el( i , 0 );
		}
	if (start < disc.rows()) end++;
	}
return recv;
}
