/* @(#) matpow.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: matpow.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  MATPOW_FAIL_NOT_SQR 25
#define  MATPOW_FAIL_INVERSE_ONLY 26

matrix operator^(matrix& arg1, int arg2)  /* FUNCTION */
	{
matrix answer;	

	if  ( arg1.rows() != arg1.rows() )
		{
		error_signal(mcpp_env, MATPOW_FAIL_NOT_SQR);
		}

	if ( arg2 == -1 ) return(sweep( arg1 ));
	else
		{
		error_signal(mcpp_env, MATPOW_FAIL_INVERSE_ONLY);
		}
	}
