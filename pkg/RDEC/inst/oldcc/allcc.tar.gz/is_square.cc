/* @(#) is_square.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: is_square.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

int is_square( matrix& inmat )  /* FUNCTION */
	{
	return ( inmat.rows() == inmat.cols() );
	}

