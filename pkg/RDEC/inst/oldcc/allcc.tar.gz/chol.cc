
/* @(#) chol.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: chol.c (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#include "math.h"
#define CHOL_FAIL_NOT_SQR 2
#define CHOL_FAIL_ILLG_DIAG 3
#define CHOL_FAIL_NON_POS 4

matrix chol(matrix& x)  /* form cholesky decomp of x */  /* FUNCTION */
			/* x = u'u with u upper right triangular */
{
matrix null;
int p = x.rows();

if ( p != x.cols() )
	{
	error_signal(mcpp_env, CHOL_FAIL_NOT_SQR);
	}

matrix tmp = x;
double* tmphead = tmp.mathead();

#define loctmp( i , j ) *(tmphead + ( i * p ) + j )  /* element reference for assn */

for ( int i = 0 ; i < p ; i++ )
	{
	double accum = 0.;

	for ( int k = 0 ; k <= i-1 ; k++ )
		{
		accum += tmp.el(k,i) * tmp.el(k,i);
		}

	if ( ( tmp.el(i,i) - accum ) >= 0. )
		{
		loctmp( i , i ) = (double) sqrt( tmp.el(i,i) - accum );
		}
	else 
		{
	error_signal(mcpp_env, CHOL_FAIL_ILLG_DIAG);
		}


	for ( int j = i+1  ; j < p ; j++ )
		{
		double accum2 = 0.;
		for ( int k = 0 ; k <= i-1 ; k++ )
			{
			accum2 += tmp.el(k,i) * tmp.el(k,j);
			}
		if ( tmp.el(i,i) > 0. ) loctmp( i , j ) = ( tmp.el(i,j) - accum2 )/tmp.el(i,i);
		else 
			{
			error_signal(mcpp_env, CHOL_FAIL_NON_POS);
			}
		loctmp( j , i ) = 0.;
		}
	}
return tmp;
}
