
/* @(#) col_1s.cc %I% %D% */
/* %P%*/
 
static char SCID[] = "@(#) MC++: col_1s.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix col_1s( int i )  /* FUNCTION */
{
matrix tmp ;

tmp = newmat( i , 1 );
double* head = tmp.mathead();

for ( int j = 0 ; j < i ; j++ ) 
	*(head++) = 1.;
return tmp;
}
