/* @(#) plug.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: plug.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  PLUG_FAIL_DIM_AGRMNT 31

void plug( matrix& plugm, matrix& socket, int row, int col)  /* FUNCTION */
{
int pcol = plugm.cols();
int prow = plugm.rows();

if (( pcol+col > ( socket.cols() ) ) || ( prow + row > socket.rows() ))
	{
	error_signal(mcpp_env, PLUG_FAIL_DIM_AGRMNT);
	}

double* sockload = socket.mathead() + col + row*(socket.cols());
double* plughead = plugm.mathead();
double* sockrow_start = sockload;

for ( int i = 0 ; i < prow ; i++ )
	{
	sockload = sockrow_start;
	for ( int j = 0 ; j < pcol ; j++ )
		{
		*(sockload++) = *(plughead++);
		}
	sockrow_start += socket.cols();
	}
}
