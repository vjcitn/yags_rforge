/* @(#) length.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: length.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

int length( matrix& in )
	{
	return in.rows() * in.cols();
	}
