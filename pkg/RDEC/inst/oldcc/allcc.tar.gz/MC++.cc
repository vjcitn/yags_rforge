/* @(#) MC++.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: MC++.c (c) V. Carey, ver. %I% , %D%";

void MCpp(){}
