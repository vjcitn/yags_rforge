/* @(#) fsweep.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: fsweep.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#include <math.h>
#define  FSWEEP_FAIL_TOO_SMALL 16
#define  FSWEEP_FAIL_NOT_SEMIDEF 17

extern "C" void * syminv_( double* , int* , int* ,
				double* , double* , int*, int* );

/* fsweep -- calls the AS syminv for fast inversion of symm pd mat */

matrix fsweep( matrix& mat ) /* FUNCTION */
{
matrix null;
int n = mat.cols();
int nn = n*(n+1)/2;

matrix tri = lower_triangularization( mat );

matrix res = newmat(nn,1);

matrix scratch = newmat(n+1,1);

double* a = tri.mathead();
double* c = res.mathead();
double* w = scratch.mathead();
int nullty, ifault;

syminv_( a , &n , &nn , c , w , &nullty , &ifault );

switch( ifault )
	{
	case 1:
		error_signal(mcpp_env, FSWEEP_FAIL_TOO_SMALL);
		break;
	case 2:
		error_signal(mcpp_env, FSWEEP_FAIL_NOT_SEMIDEF);
		break;
	default:
		break;
	}

return untriangularize( res );
}

matrix lower_triangularization( matrix& mat )
{

int n = mat.cols();
int nn = n*(n+1)/2;

double *target, *source;

matrix tri = newmat(nn,1);

target = tri.mathead();
source = mat.mathead();

int j = 0;
int k = n;
for ( int i = 0 ; i < nn ; i++ )
	{
	if ( ( j>0 ) && (( (j-1) % (n+1) ) == 0) ) 
		{
		k--;
		j+=k;
		}
	*(target+i) = *(source+j);
	j++;
	}
return tri;
}

matrix untriangularize( matrix& mat )
{
int nn = length(mat);
double dnn = (double)nn;
int n = (int)((sqrt((double)1.+8*dnn) -1.)/2.);
matrix out = newmat(n,n);
double* source = mat.mathead();
double* outp = out.mathead();
int j = 0;
int k = n;
for ( int i = 0 ; i < nn ; i++ )
	{
	if ( ( j>0 ) && (( (j-1) % (n+1) ) == 0) ) 
		{
		k--;
		j+=k;
		}
	*(outp+j) = *(source+i);
	j++;
	}
	/* now upper tri has been formed */
out = out + transp(out);   /* now square mat with doubled trace */
for ( i = 0 ; i < n ; i++ )
	set_el( out , i , i ) = out.el(i,i)/2.;
return out;
}
		

