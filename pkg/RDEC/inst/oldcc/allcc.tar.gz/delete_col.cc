
/* @(#) delete_col.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: delete_col.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  DELCOL_FAIL_NO_COL 11


matrix delete_col( matrix& X, int i)  /* FUNCTION */
	/* i is col to delete , zerobased */
{
matrix result;
matrix null;
int ncop, nresel, skip;
double *resbase, *Xbase;

if (X.cols() <= 1)
	{
	error_signal(mcpp_env, DELCOL_FAIL_NO_COL);
	}

result = transp ( delete_row( transp( X ) , i ) );

return result;
}

