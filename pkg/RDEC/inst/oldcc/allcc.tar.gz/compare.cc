/* @(#) compare.cc %I% %D% */
/* %P%*/
 
static char SCID[] = "@(#) MC++: compare.cc (c) V. Carey, ver. %I% , %D%";

/* standard scalar comparison for floats */

int compare( const void* i , const void* j )
{
int dir = 1;

if ((double *)i < (double *)j) dir = -1;
else if ((double *)i == (double *)j) dir = 0;
return dir;
}
