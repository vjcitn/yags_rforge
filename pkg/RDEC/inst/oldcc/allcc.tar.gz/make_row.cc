/* @(#) make_row.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: make_row.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix make_row( double in)
	{
	matrix x = newmat(1,1);
	set_el(x,0,0) = in;
	return x;
	};
matrix make_row( double in1, double in2)
	{
	matrix x = newmat(1,2);
	set_el(x,0,0) = in1;
	set_el(x,0,1) = in2;
	return x;
	};
matrix make_row( double in1, double in2, double in3)
	{
	matrix x = newmat(1,3);
	set_el(x,0,0) = in1;
	set_el(x,0,1) = in2;
	set_el(x,0,2) = in3;
	return x;
	};

matrix make_row( double in1, double in2, double in3, double in4)
	{
	matrix x = newmat(1,4);
	set_el(x,0,0) = in1;
	set_el(x,0,1) = in2;
	set_el(x,0,2) = in3;
	set_el(x,0,3) = in4;
	return x;
	};
matrix make_row( double in1, double in2, double in3, double in4, double
in5)
	{
	matrix x = newmat(1,5);
	set_el(x,0,0) = in1;
	set_el(x,0,1) = in2;
	set_el(x,0,2) = in3;
	set_el(x,0,3) = in4;
	set_el(x,0,4) = in5;
	return x;
	};
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6)
	{
	matrix x = newmat(1,6);
	set_el(x,0,0) = in1;
	set_el(x,0,1) = in2;
	set_el(x,0,2) = in3;
	set_el(x,0,3) = in4;
	set_el(x,0,4) = in5;
	set_el(x,0,5) = in6;
	return x;
	};
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7)
	{
	matrix x = newmat(1,7);
	set_el(x,0,0) = in1;
	set_el(x,0,1) = in2;
	set_el(x,0,2) = in3;
	set_el(x,0,3) = in4;
	set_el(x,0,4) = in5;
	set_el(x,0,5) = in6;
	set_el(x,0,6) = in7;
	return x;
	};

matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 );
	}
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8, double in9)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 , in9);
	}
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8, double in9, double in10)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 , in9,
	in10);
	}
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8, double in9, double in10, double in11)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 , in9,
	in10, in11);
	}
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8, double in9, double in10, double in11,
double in12)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 , in9,
	in10, in11, in12);
	}
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8, double in9, double in10, double in11,
double in12, double in13)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 , in9,
	in10, in11, in12) || make_row( in13 );
	}
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8, double in9, double in10, double in11,
double in12, double in13, double in14)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 , in9,
	in10, in11, in12) || make_row( in13, in14 );
	}
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8, double in9, double in10, double in11,
double in12, double in13, double in14, double in15)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 , in9,
	in10, in11, in12) || make_row( in13, in14 , in15);
	}
matrix make_row( double in1, double in2, double in3, double in4, double
in5, double in6, double in7, double in8, double in9, double in10, double in11,
double in12, double in13, double in14, double in15, double in16)
	{
	return make_row( in1, in2, in3, in4, in5, in6 ) || make_row( in7, in8 , in9,
	in10, in11, in12) || make_row( in13, in14 , in15, in16);
	}
