/* @(#) fromstream.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: fromstream.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

#ifndef FOR_S
istream& operator>>(istream& s, matrix& mat)  /* FUNCTION */
	{

	for ( int i = 0 ; i < mat.ncols * mat.nrows ; i++ )
		{
		s >> mat.data[i];
		}
	return s;

	}
#endif
