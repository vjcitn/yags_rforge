
/* @(#) mat11.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: mat11.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix mat11(double x)  /* make a matrix object from a scalar */
{
matrix go = newmat(1,1);
set_el(go,0,0) = x;
return go;
}

matrix mat11(int x)
{
return mat11((double)x);
}


