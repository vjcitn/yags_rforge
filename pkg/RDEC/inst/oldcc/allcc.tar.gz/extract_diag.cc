/* @(#) extract_diag.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: extract_diag.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  EXTRACT_FAIL_NOT_SQR 14

matrix extract_diag( matrix& inmat )   /* FUNCTION */
{
matrix null;
if ( !is_square(inmat) )
	{
	error_signal(mcpp_env, EXTRACT_FAIL_NOT_SQR);
	}
	
matrix tmp = newmat( inmat.rows(), 1 );
double* tmphead = tmp.mathead();

for ( int i = 0 ; i < inmat.rows() ; i++ )
	{
	*(tmphead++) = inmat.el(i,i);
	}
return tmp;
}


