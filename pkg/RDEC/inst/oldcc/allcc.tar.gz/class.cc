
/* @(#) class.cc %I% %D% */
/* %P% */

static char SCID[] = "@(#) MC++: class.cc (c) V. Carey, ver. %I% , %D%";

class matrix {

		int nrows, ncols;
		double *data;
	public:
		matrix();
		matrix(matrix&); // for initialztn of uninit vbl p. 180
		~matrix();  

		friend matrix newmat(int i, int j);

		double el(int i, int j) { return *(data+(ncols*i)+j); };
		matrix submat( matrix& row_req , matrix& col_req );
		matrix submat( matrix& row_req , int dummy  );
		matrix submat( int dummy , matrix& col_req ); 

		double *mathead() { return data; };

		int rows() { return nrows; };
		int cols() { return ncols; };

		friend matrix operator*( matrix& , matrix& );
		friend matrix operator*( double , matrix& );
		friend matrix operator*( matrix& , double );

		friend matrix operator+( matrix& , matrix& );
		friend void operator+=( matrix& , matrix& );
		friend matrix operator-( matrix& , matrix& );
		friend void operator-=( matrix& , matrix& );

		friend matrix operator||( matrix& , matrix& );  /* H-CONCAT */
		friend matrix operator/( matrix& , matrix& );   /* V-CONCAT */

		friend matrix matlog( matrix& );

		void operator=( matrix& );  /* assignment */
		friend void kill( matrix& );

		};

matrix::matrix()     /* basic constructor */
	{            /* initialize metadata, prepare for assn or newmat */
	nrows = 0;
	ncols = 0;
	};

matrix::matrix(matrix& inmat)   /* constructor for initialization by existing object */
	{
	nrows = inmat.nrows;
	ncols = inmat.ncols;
	data = new double[ nrows*ncols ];
	for ( int i = 0 ; i < nrows*ncols ; i++ )
		{
		data[i] = inmat.data[i];
		}
	};

matrix::~matrix()      /* destructor */
	{
	if ( nrows*ncols > 0 ) delete data;
	};

void matrix::operator=( matrix& inmat )  // assignment !!
	{				 // assumption -- this refers to lhs
	if ( this == &inmat ) return;    // inmat=inmat
	if ( this->nrows > 0 ) delete data; /* cleans old mat */
	this->nrows = inmat.nrows;
	this->ncols = inmat.ncols;
	int nelem = inmat.nrows*inmat.ncols ;
	this->data = new double[ nelem ];
	for ( int i = 0 ; i < nelem ; i++ )
		{
		this->data[i] = inmat.data[i];
		}
	};

