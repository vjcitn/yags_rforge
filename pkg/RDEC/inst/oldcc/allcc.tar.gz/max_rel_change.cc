/* @(#) max_rel_change.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: max_rel_change.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#include <math.h>

#define MAXREL_FAIL_NONMATCH_ARGS 27


double max_rel_change( matrix& old , matrix& New )
	{
	int oldr = old.rows();
	int oldc = old.cols();
	int Newr = New.rows();
	int Newc = New.cols();
	if ( ( oldr != Newr ) || ( oldc != Newc ) )
		{
		error_signal(mcpp_env, MAXREL_FAIL_NONMATCH_ARGS);
		}
	double max = 0.;
	for ( int i = 0 ; i < oldr ; i++ )
		{
		for ( int j = 0 ; j < oldc ; j++ )
			{
			double achg = fabs((New.el(i,j) - old.el(i,j))/old.el(i,j));
			if (achg > max) max = achg;
			}
		}
	return max;
	}
