/* @(#) submat.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: submat.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#define  SUBMAT_FAIL_NOT_ROWVEC 41
#define  SUBMAT_FAIL_NOT_COLVEC 42
#define  SUBMAT_FAIL_CHECK_ROWS 43 
#define  SUBMAT_FAIL_CHECK_COLS 44

matrix matrix::submat( matrix& row_req , int dummy )  /* FUNCTION */
	{
		/* set up the (complete) col req */
	int srccols = this->ncols;
	matrix crq = newmat( 1 , srccols );

	double* load = crq.mathead();

	for ( int j = 0 ; j < srccols ; j++ )
		{
		*(load++) = (double)j;
		}

	matrix tmp = this->submat( row_req, crq );
	return tmp;
	}

matrix matrix::submat( int dummy , matrix& col_req )  /* FUNCTION */
	{
	int srcrows = this->nrows;
	matrix rrq = newmat( 1 , srcrows ) ;

	double* load = rrq.mathead();

	for ( int i = 0 ; i < srcrows ; i++ )
		{
		*(load++) = (double)i;
		}
	matrix tmp = this->submat( rrq, col_req );
	return tmp;
	}

matrix matrix::submat( matrix& row_req , matrix& col_req )  /* FUNCTION */
	{
matrix crq, rrq;
matrix null;
	/* put "request mats " in canonical form -- as row vecs */
	if ( row_req.rows() == 1 ) /* is a row vector */
		{
		rrq = row_req;
		}
	else if ( row_req.cols() == 1 )
		{
		rrq = transp( row_req );
		}
	else
		{
		error_signal(mcpp_env, SUBMAT_FAIL_NOT_ROWVEC);
		}
	if ( col_req.rows() == 1 ) /* is a row vector */
		{
		crq = col_req;
		}
	else if ( col_req.cols() == 1 )
		{
		crq = transp( col_req );
		}
	else
		{
		error_signal(mcpp_env, SUBMAT_FAIL_NOT_COLVEC);
		}
	int n_r_pulls = rrq.cols();
	int n_c_pulls = crq.cols();
	int srccols = this->ncols;
	int srcrows = this->nrows;

	if ( (int)max(rrq) > (srcrows-1))
		{
		error_signal(mcpp_env, SUBMAT_FAIL_CHECK_ROWS);
		}
	if ( (int)max(crq) > (srccols-1))
		{
		error_signal(mcpp_env, SUBMAT_FAIL_CHECK_COLS);
		}

	matrix tmp = newmat( n_r_pulls, n_c_pulls );

	double* load = tmp.mathead();

	for ( int i = 0 ; i < n_r_pulls ; i++ )
		{
		for ( int j = 0 ; j < n_c_pulls ; j++ )
			{
			*(load++) = this->data[ (int)rrq.el(0,i)*srccols + (int)crq.el(0,j) ];
			}
		}
	return tmp;
	}
