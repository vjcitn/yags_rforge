/* @(#) covlag.cc %I% %D% */
/* %P%*/
 
static char SCID[] = "@(#) MC++: covlag.cc (c) V. Carey, ver. %I% , %D%";


#include "MC++.h"
#define  COVLAG_FAIL_MATX_SIZE 10


/* covlag -- see IML p.114 */

matrix covlag( matrix& inmat , int lag , int demean = 0 )
	{
	matrix null;
	matrix xrows[30];
	int n = inmat.rows();
	if ( n > 30 )
		{
		error_signal(mcpp_env, COVLAG_FAIL_MATX_SIZE);
		}
	int nv = inmat.cols();

	matrix res = newmat( nv, lag*nv );

	for ( int q = 0 ; q < n ; q++ )
		{
		xrows[q] = rowseg( inmat , q , 1 );
		}
	for ( q = n ; q < 30 ; q++ )
		{
		xrows[q] = newmat( 1 , 1 ); //patch for dumb deleter
		}

	matrix temp = newmat( nv , nv );

	for ( int i = 0 ; i < lag ; i++ )
		{
		for ( int j = i ; j < n ; j++ )
			{
			       /* thanks to zero-basing, we can drop SAS -1 term in indexing */
			if ( (j-i) < n ) temp += transp( xrows[j] ) * xrows[ (j - i) ];
			}
		plug( temp * (double)(1./n), res , 0, i*nv );
		temp -= temp;
		}
	return res;
	}

