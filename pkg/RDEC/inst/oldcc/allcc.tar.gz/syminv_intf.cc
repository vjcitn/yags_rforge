/* @(#) syminv_intf.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: syminv_intf.cc (c) V. Carey, ver. %I% , %D%";

extern "C" syminv_( double*, int*, int*, double*,double*,int*, int*, int*);

void * syminv_intf( double* a , int* n , int* nn ,
			    double* c ,double* w ,int* nullty , int* ifault )
	{
	int nargs = 7;
	syminv_( a , n , nn , c , w , nullty , ifault , &nargs);
	return 0;
	}

