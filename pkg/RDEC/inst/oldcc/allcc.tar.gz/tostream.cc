/* @(#) tostream.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: tostream.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"
#include <math.h>

#ifndef FOR_S
ostream& operator<<(ostream&s , matrix& arg1) /* FUNCTION */
	{
	// this program uses the 2.0 manipulators to set up
	// the matrix-to-ostream delivery system
	//
	//  width of element output = ELWIDTH
	//  precision of element display = ELPREC
	//  elements right-aligned in their cells
	//  sci. not. used for numbers of aberrant magnitudes
	//
	int ELWIDTH = 10;
	int ELPREC = 4;
	s << endl;
	for ( int i = 0 ; i < arg1.rows() ; i++ )
		{
		for ( int j = 0 ; j < arg1.cols() ; j++ )
			{
			double x = (double)arg1.el(i,j);
			s.width(ELWIDTH);
			s.setf(ios::adjustfield,ios::right);
			s.setf(ios::fixed);
			if ( fabs(x) > exp(ELPREC*log(10.))-1. || 
					fabs(x) < exp(-ELPREC*log(10.)) ) {
				s.setf(ios::scientific);
				}
			s.precision(ELPREC);
			s << x << "  ";
			s.unsetf(ios::scientific);  // not nice?
			}
		s << endl ;
		}
	return s;
	}
#endif
