/* @(#) corner.cc %I% %D% */
/* %P%*/
 
static char SCID[] = "@(#) MC++: corner.cc (c) V. Carey, ver. %I% , %D%";


#include "MC++.h"

matrix corner( matrix& inmat , int nr , int nc )
	{
	matrix out = newmat( nr , nc );
	for ( int i = 0 ; i < nr ; i++ )
		{
		for ( int j = 0 ; j < nr ; j++ )
			{
			set_el( out , i , j ) = inmat.el( i , j );
			}
		}
	return out;
	}

