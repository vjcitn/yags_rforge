#include "MC++.h"
jmp_buf mcpp_env;
main()
{
matrix x = matread("X");
cout << x;
}

