/* @(#) ident.cc %I% %D% */
/* %P% */
 
static char SCID[] = "@(#) MC++: ident.cc (c) V. Carey, ver. %I% , %D%";

#include "MC++.h"

matrix ident( int i )  /* FUNCTION */
{
matrix tmp;

tmp = newmat( i , i );
double* head = tmp.mathead();

for ( int j = 0 ; j < i ; j++ )
	*(head+( (i+1)*j )) = 1.;
return tmp;
}
