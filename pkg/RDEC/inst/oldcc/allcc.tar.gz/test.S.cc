#include "MC++.h"

void catter(double* x, int* n)
{
matrix X = from_S( x, *n, 1 );
matdump(X);
}
